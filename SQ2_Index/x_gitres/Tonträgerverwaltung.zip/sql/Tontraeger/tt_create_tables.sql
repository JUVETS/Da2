-- tt_create_tables.sql
--
-- Projekt      : Datenbanken
-- Version      : 1.0
-- Autor        : Lukas Müller
-- Erstelldatum : 24.09.2019
-- Bemerkungen  : 
--
-- Change log
-- 24.09.2019   LUK Tabelle Traeger erweitert mit Datum

--
-- Datenbank erstellen
--
drop database Tontraeger;
go
create database Tontraeger;
go
use Tontraeger;


--
-- Step 1, Tabellen erstellen
--


--
-- Tabelle Traeger erstellen
--
create table Traeger
(
	TraegerID 	int 		not null identity(1,1),
    TraegerName	varchar(45) not null,
    constraint pk_traeger primary key (TraegerID)
);

--
-- Tabelle Ort erstellen
--
create table Ort
(
	OrtID 		int 		not null identity(1,1),
    Ort 		varchar(45) not null,
    constraint pk_ort primary key (OrtID)
);

--
-- Tabelle Stil erstellen
--
create table Stil
(
	StilID 		int 		not null identity(1,1),
    Stil 		varchar(45) not null,
    constraint pk_stil primary key (StilID)
);

--
-- Tabelle Musikstuek erstellen
--
create table Musikstueck
(
	MusikstueckID 	int 			not null identity(1,1),
    Titel 			varchar(45) 	not null,
    Dauer 			decimal(4,2)	null default 0.0,
    Bewertung 		decimal(2,1),
    constraint pk_musikstueck primary key (MusikstueckID)
);

--
-- Tabelle Interpret erstellen
--
create table Interpret
(
	InterpretID 	int 		not null identity(1,1),
    InterpretName	varchar(45) not null,
    constraint pk_interpret primary key (InterpretID)
);

--
-- Tabelle Alben erstellen
--
create table Album
(
	AlbumID 	int 			not null identity(1,1),
    Titel 		varchar(45) 	not null,
    Note 		decimal(2,1)	null		default 1.0,
    OrtID 		int				not null,
    StilID 		int				not null,    
    constraint pk_alben primary key (AlbumID)
);

--
-- Tabelle AlbumInhalt erstellen
--
create table AlbumInhalt
(
    AlbumID 		int not null,
    MusikstueckID 	int not null,
    constraint pk_albuminhalt primary key (AlbumID, MusikstueckID)
);

--
-- Tabelle InterpretList erstellen
--
create table InterpretList
(
    MusikstueckID 		int not null,
    InterpretID 		int not null,
    constraint pk_InterpretList primary key (MusikstueckID, InterpretID)
);

--
-- Tabelle TraegerList erstellen
--
create table TraegerList
(
    TraegerID 		int not null,
    AlbumID 		int not null,
    constraint pk_traegerlist primary key (TraegerID, AlbumID)
);

--
-- Step 2, foreign key constraints erstellen
--
alter table Album
	add constraint fk_album_stil foreign key (StilID) references Stil(StilID);

alter table Album
	add constraint fk_album_ort foreign key (OrtID) references Ort(OrtID);

alter table AlbumInhalt
	add constraint fk_albuminhalt_musikstueck foreign key (MusikstueckID) references Musikstueck(MusikstueckID),
        constraint fk_albuminhalt_alben foreign key (AlbumID) references Album(AlbumID);

alter table InterpretList
	add constraint fk_musikinterpret_musikstueck foreign key (MusikstueckID) references Musikstueck(MusikstueckID),
        constraint fk_musikinterpret_interpret foreign key (InterpretID) references Interpret(InterpretID);

alter table TraegerList
	add constraint fk_traegerlist_traeger foreign key (TraegerID) references Traeger(TraegerID),  
        constraint fk_traegerlist_album foreign key (AlbumID) references Album(AlbumID);
    
--
-- Step 3 Unique Constraints
--

alter table Traeger
	add constraint uq_traeger_traeger unique (Traegername);
    
alter table Ort
	add constraint uq_ort_ort unique (Ort);
    
alter table Stil
	add constraint uq_stil_stil unique (Stil);    
    
alter table Interpret
	add constraint uq_interpret_interpret unique (InterpretName);  
    
--
-- Step 4, Indices erstellen
-- 
create index idx_Album_Titel on Album (Titel);

create index idx_Musikstueck_Titel on Musikstueck (Titel);

create index idx_Album_StilID on Album (StilID);

create index idx_Alben_OrtID on Album(OrtID);


--
-- Check constraints erstellen
--
alter table Album
	add constraint chk_album_noten check (note >= 1.0 and note <= 6.0);
    
    
    