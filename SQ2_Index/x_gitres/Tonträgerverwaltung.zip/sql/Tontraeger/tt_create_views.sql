-- tt_create_views.sql
--
-- Projekt      : Modul 153
-- Version      : 1.0
-- Autor        : Lukas Müller
-- Erstelldatum :
-- Bemerkungen  : 
--
-- Change log

use tontraeger;
go

-- View erstellen
create view albenlocationview(AlbumTitel, AlbumNote, Ort)
as
select album.Titel, album.note, ort.Ort
	from Album inner join Ort
		on album.Ortid = ort.ortid;
go

-- View abfragen
select * from albenlocationview
	where Ort = 'CD-Ständer';
