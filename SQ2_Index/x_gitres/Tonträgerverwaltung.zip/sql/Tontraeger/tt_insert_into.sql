-- tt_insert_into.sql
--
-- Projekt      : Datenbanken
-- Version      : 1.0
-- Autor        : Lukas Müller
-- Erstelldatum : 25.09.2019
-- Bemerkungen  : 
--
-- Change log

use tontraeger;

print 'Daten werden eingefügt...';

SET IDENTITY_INSERT stil ON;

INSERT INTO stil (StilID, Stil)
VALUES  (1, 'Pop'),
		(2, 'Accapella'),
        (3, 'Kabarett Rock');
SET IDENTITY_INSERT stil OFF;

SET IDENTITY_INSERT Ort ON;
insert into Ort(OrtID, Ort)
	values	(1, 'CD-Ständer'),
			(2, 'Kasten');
SET IDENTITY_INSERT Ort OFF;

SET IDENTITY_INSERT Traeger ON;
insert into Traeger(TraegerID, Traegername)
			values	(1, 'CD'),
					(2, 'MC');
SET IDENTITY_INSERT Traeger OFF;

SET IDENTITY_INSERT Interpret ON;                  
insert into Interpret(InterpretID, InterpretName)
			values	(1, 'Stefan Eicher'),
					(2, 'Roxette'),
                    (3, 'Die Prinzen'),
                    (4, 'Nimm Zwei'),
                    (5, 'ace of base');                  
SET IDENTITY_INSERT Interpret OFF;                  

SET IDENTITY_INSERT Album ON; 
insert into Album(AlbumID, Titel, Note, OrtID, StilID)
			values	(1, 'i tell this night', 5, 1, 1),
					(2, 'Pop95', 5.5, 2, 1),
                    (3, 'Das Leben ist grausam', 5, 1, 2),
                    (4, 'Wir wollen nur deine Seele', 5.5, 1, 3);
SET IDENTITY_INSERT Album OFF; 
                    
insert into TraegerList(TraegerID, AlbumID)
			values (1,1),
				   (2,2),
                   (1,3),
                   (1,4);

SET IDENTITY_INSERT Musikstueck ON; 
insert into Musikstueck(MusikstueckID, Titel, Dauer, Bewertung)
	values	(1, 'i tell this night', 4.52, 5.0),
			(2, 'Two people in a room', 4.08, 5.5),
            (3, 'Tu tournes mon coeur', 4.43, 4.5),
            (4, 'Joyride', 4.3, 5.5),
            (5, 'Gabi und Klaus', 3.23, 5.5),
            (6, 'Happy Nation', 4.0, 5.5),
            (7, 'Mein Fahrrad', 2.25, 5.5),
            (8, 'Die Vögel', 4.52, 3.5),
            (9, 'Mr. Pharao', 5.46, 6.0),
            (10, 'Slimer', 3.48, 6.0),
            (11, 'Wie ein Sturm', 5.35, 5.0);
SET IDENTITY_INSERT Musikstueck OFF; 

insert into interpretlist(musikstueckID, InterpretID)
	values 	(1, 1),
			(2, 1),
            (3, 1),
            (4, 2),
            (5, 3),
            (6, 5),
            (7, 3),
            (8, 3),
            (9, 4),
            (10, 4),
            (11, 4);
            
 insert into AlbumInhalt(AlbumID, MusikstueckID)
	values 	(1, 1),
			(1, 2),
            (1, 3),
            (2, 4),
            (2, 5),
            (2, 6),
            (3, 5),
            (3, 7),
            (3, 8),
            (4, 9),
            (4, 10),
            (4, 11);

print 'Daten wurden eingefügt';
           