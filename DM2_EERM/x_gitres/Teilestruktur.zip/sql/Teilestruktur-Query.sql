-- Welche Bestandteile hat der Artikel mit 
-- der Teile Nr. (TNr) = 60
select t.tnr, s.uteil
    from teile t inner join struktur s
        on t.tnr = s.oteil
    where t.tnr = 60

select t.tnr, t2.tnr, t2.Bezeichnung
    from teile t inner join struktur s
			on t.tnr = s.oteil
		inner join teile t2
			on s.UTeil = t2.TNr
    where t.tnr = 60

-- Die in der Baugruppe enthaltenen Teile werden 
-- aufgel�st (2 stufig)
select t.tnr, s1.uteil, s2.uteil
from teile t inner join struktur s1
    on t.tnr = s1.oteil
    inner join struktur s2
    on s1.uteil = s2.oteil
    where t.tnr = 60

select t.tnr, s1.uteil, s2.uteil, t2.Bezeichnung
from teile t inner join struktur s1
		on t.tnr = s1.oteil
    inner join struktur s2
		on s1.uteil = s2.oteil
	inner join teile t2
		on s2.UTeil = t2.TNr
    where t.tnr = 60


-- Die in der Baugruppe enthaltenen Teile werden aufgel�st (3 stufig)
select t.tnr, s1.uteil, s2.uteil, s3.uteil
from teile t inner join struktur s1
    on t.tnr = s1.oteil
    inner join struktur s2
    on s1.uteil = s2.oteil
    inner join struktur s3
    on s2.uteil = s3.oteil
    where t.tnr = 60

